﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using BankManage.common;

namespace BankManage
{
    public class CustomChecking : Custom
    {
        /// 开户
        /// </summary>
        /// <param name="accountNumber">帐号</param>
        /// <param name="money">开户金额</param>
        public override void Create(string accountNumber, double money)
        {
            base.Create(accountNumber, money);
            base.Diposit("结息", DataOperation.GetRate(RateType.活期) * money);
        }

        /// <summary>
        ///存款 
        /// </summary>
        public override void Diposit(string genType, double money)
        {
            BankEntities context = new BankEntities();
            var q = (from c in context.MoneyInfo
                     where c.accountNo == AccountInfo.accountNo & c.balance == AccountBalance
                     select c.dealDate).Single();
            DateTime start = q;
            DateTime end = DateTime.Now;
            int ts = (end - start).Days;
            base.Diposit("结息", DataOperation.GetRate(RateType.活期) * money * (ts / 365));
            base.Diposit("存款", money);
        }

        /// <summary>
        ///取款 
        /// </summary>
        /// <param name="money">取款金额</param>
        public override void Withdraw(double money)
        {
            if (!ValidBeforeWithdraw(money)) return;
            BankEntities context = new BankEntities();
            var q = (from c in context.MoneyInfo
                     where c.accountNo == AccountInfo.accountNo & c.balance == AccountBalance
                     select c.dealDate).Single();
            DateTime start = q;
            DateTime end = DateTime.Now;
            int ts = (end - start).Days;
            base.Diposit("结息", DataOperation.GetRate(RateType.活期) * money * (ts / 365));
            //取款
            base.Withdraw(money);
        }
    }
}
