﻿using BankManage.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace BankManage.money
{
    public class Fixedthree:Custom
    {
        public RateType type { get; set; }
        /// 开户
        /// </summary>
        /// <param name="accountNumber">帐号</param>
        /// <param name="money">开户金额</param>
        public override void Create(string accountNumber, double money)
        {
            base.Create(accountNumber, money);
        }

        /// <summary>
        ///存款 
        /// </summary>
        DateTime now = DateTime.Now;
        BankEntities context = new BankEntities();

        public override void Diposit(string genType,double money)
        {
            base.Diposit("存款", money);
            //结算利息
            var q = (from n in context.MoneyInfo
                     where n.accountNo == AccountInfo.accountNo & n.dealType == "开户"
                     select n.dealDate).Single();
            if (now > q.AddYears(3))
            {
                base.Diposit("结息", DataOperation.GetRate(RateType.定期3年) * money);
            }
            else
            {
                MessageBox.Show("账户处于定期期限内，不能存款");
            }
        }

        /// <summary>
        ///取款 
        /// </summary>
        /// <param name="money">取款金额</param>
        public override void Withdraw(double money)
        {
            if (!ValidBeforeWithdraw(money)) return;
            //计算利息
            var q = (from n in context.MoneyInfo
                     where n.accountNo == AccountInfo.accountNo & n.dealType == "开户"
                     select n.dealDate).Single();
            DateTime end = q;
            int day = (end - now).Days;
            if (now > q.AddYears(3))
            {
                double interest = DataOperation.GetRate(RateType.定期3年) * AccountBalance * 3 + DataOperation.GetRate(RateType.定期超期部分) * AccountBalance * (day - 365*3) / 365;
                base.Diposit("结息", interest);
                base.Withdraw(money);
            }
            else
            {
                double interest = DataOperation.GetRate(RateType.定期提前支取) * AccountBalance * day / 365;
                base.Diposit("结息", interest);
                base.Withdraw(money);
            }
            
        }
    }
}
