﻿using BankManage.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace BankManage.money
{
    public class Flexiblethree : Custom
    {
        public RateType type { get; set; }
        /// 开户
        /// </summary>
        /// <param name="accountNumber">帐号</param>
        /// <param name="money">开户金额</param>
        public override void Create(string accountNumber, double money)
        {
            base.Create(accountNumber, money);
        }

        /// <summary>
        ///存款 
        /// </summary>
        int times = 1;
        public override void Diposit(string genType, double money)
        {
            times = times + 1;
            if (times == 36)
            {
                MessageBox.Show("存款次数已达上限");
            }
            else
            {
                base.Diposit("存款", money);
                base.Diposit("结息", DataOperation.GetRate(RateType.零存整取3年) * money);
            }


        }

        /// <summary>
        ///取款 
        /// </summary>
        /// <param name="money">取款金额</param>
        public override void Withdraw(double money)
        {
            BankEntities context = new BankEntities();
            DateTime now = DateTime.Now;
            var q = (from v in context.MoneyInfo
                     where v.accountNo == AccountInfo.accountNo & v.dealType == "开户"
                     select v.dealDate).Single();
            DateTime start = q;
            int day = (now - start).Days;
            if (!ValidBeforeWithdraw(money)) return;
            //计算利息
            double interest = 0;
            var count = from m in context.MoneyInfo
                        where m.accountNo == AccountInfo.accountNo & m.dealType != "结息"
                        select m.dealMoney;
            int counts = count.Count();
            if (now >= q.AddYears(3))
            {
                if (counts == 36)
                {
                    int i = 0;
                    foreach (var v in count)
                    {
                        interest += DataOperation.GetRate(RateType.零存整取3年) * v * (36 - i) / 12;
                        base.Diposit("结息", interest);
                        i++;
                    }
                }
                else
                {
                    int w = 0;
                    foreach (var j in count)
                    {
                        interest += DataOperation.GetRate(RateType.零存整取违规) * j * (36 - w) / 12;
                        base.Diposit("结息", interest);
                        w++;
                    }
                }
                interest += DataOperation.GetRate(RateType.零存整取超期部分) * AccountBalance * (day - 365) / 365;
                base.Diposit("结息", interest);

            }
            else
            {
                int h = 0;
                foreach (var g in count)
                {
                    interest += DataOperation.GetRate(RateType.零存整取违规) * g * (counts - h) / 12;
                    base.Diposit("结息", interest);
                    h++;
                }
            }
            base.Withdraw(money);
        }
    }
}
