﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BankManage.Finance
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class finance: Page
    {
        public finance()
        {
            InitializeComponent();
        }

        

        private void choose_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            double rate = 0;
            int index = choose.SelectedIndex;
            switch (index)
            {
                case 0:
                    rate=0.023;
                    break;
                case 1:
                    rate = 0.011;
                    break;
                case 2:
                    rate = -0.014;
                    break;
                case 3:
                    rate = 0.024;
                    break;
                case 4:
                    rate = 0.012;
                    break;
                case 5:
                    rate = -0.03;
                    break;


            }
            r.Text=rate.ToString();
        }
        private void calculate_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(money.Text, out double n1)&& double.TryParse(r.Text, out double n2))
            {
                double i = n1 * n2;
                income.Text = i.ToString();
            }
            
        }
    }
}
