﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;



namespace BankManage.sysHelp
{
    /// <summary>
    /// UserHelp.xaml 的交互逻辑
    /// </summary>
    public partial class UserHelp : Page
    {
        public UserHelp()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("正在为您连接人工客服\n请稍候...");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("为迎接新年，本行推出开户送礼活动\n详情请咨询电话888888");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("更多业务还在来的路上...");
        }

    }
}
